⚠️ Estado não encontrado.
